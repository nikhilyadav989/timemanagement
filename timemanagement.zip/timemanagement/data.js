module.exports = function () {
    return { 
        products: [
            { id: "1",tid:"1", name: "CSE", category: "TEACHING", 
                description: "Parag (C++)", price: 275,sdate:"12-12-98", edate:"12-12-98",hour:"9",status:"In progress"
            ,task:"teaching", image:"./assets/nik/d1.jpg"},
            { id: 2,tid:"2", name: "CSE", category: "ASSISTANCE", 
                description: "Sumit (Java)", price: 48.95 ,sdate:"12-12-98", edate:"12-12-98",hour:"8",status:"In progress"
                ,task:"teaching",image:"./assets/nik/d.jpeg"},
            { id: 3, tid:"3",name: "ME", category: "TEACHING", 
                description: "Rohan (Foundary)", price: 19.50,sdate:"12-12-98", edate:"12-12-98",hour:"4",status:"In progress"
                ,task:"teaching" ,image:"./assets/nik/d3.jpg"},
            { id: 4,tid:"4", name: "ECE", category: "TEACHING", 
                description: "Nikhil (BEE)", 
                price: 34.95,sdate:"12-12-98", edate:"12-12-98",hour:"3",status:"In progress"
                ,task:"teaching",image:"./assets/nik/d4.jpg" },
            { id: 5,tid:"5", name: "ME", category: "ASSISTANCE", 
                description: "Parth (Engine)", price: 79500 ,sdate:"12-12-98", edate:"12-12-98",hour:"2",status:"In progress"
                ,task:"teaching",image:"./assets/nik/d5.jpg"},
            { id: 6,tid:"6", name: "CIVIL", category: "TRAINING", 
                description: "Mohit (Construction)", price: 16,sdate:"12-12-98", edate:"12-12-98",hour:"7",status:"In progress"
                ,task:"teaching" ,image:"./assets/nik/d6.jpg"},
                { id: 9,tid:"9", name: "ECE", category: "COUNSELLING", 
                description: "Deep (DE)", price: 1200 ,sdate:"12-12-98", edate:"12-12-98",hour:"9",status:"In progress"
                ,task:"teaching",image:"./assets/nik/d8.jpg"},
                { id: 9,tid:"9", name: "CIVIL", category: "COUNSELLING", 
                description: "Amar (Sand)", price: 1200 ,sdate:"12-12-98", edate:"12-12-98",hour:"9",status:"In progress"
                ,task:"teaching",image:"./assets/nik/d1.jpg"},
            { id: 7,tid:"7", name: "ECE", category: "TRAINING", 
                description: "Deepanshu (BEE)", 
                price: 29.95 ,sdate:"12-12-98", edate:"12-12-98",hour:"8",status:"In progress"
                ,task:"teaching",image:"./assets/nik/d7.jpg"},
            { id: 8,tid:"8", name: "ECE", category: "TRAINING", 
                description: "Nitin (BEEE)", price: 75,sdate:"12-12-98", edate:"12-12-98",hour:"6",status:"In progress"
                ,task:"teaching",image:"./assets/nik/d.png" },
            { id: 9,tid:"9", name: "CIVIL", category: "COUNSELLING", 
                description: "Navdeep (Architecture)", price: 1200 ,sdate:"12-12-98", edate:"12-12-98",hour:"9",status:"In progress"
                ,task:"teaching",image:"./assets/nik/d8.jpg"},
                { id: 5,tid:"5", name: "ME", category: "COUNSELLING", 
                description: "SOMYA (Engine)", price: 79500 ,sdate:"12-12-98", edate:"12-12-98",hour:"4",status:"In progress"
                ,task:"teaching",image:"./assets/nik/d5.jpg"},
                { id: 5,tid:"5", name: "ME", category: "ASSISTANCE", 
                description: "Rishabh (Engine)", price: 79500 ,sdate:"11-12-98", edate:"12-12-98",hour:"2",status:"In progress"
                ,task:"teaching",image:"./assets/nik/d7.jpg"},
                { id: 5,tid:"5", name: "ME", category: "ASSISTANCE", 
                description: "Aniket (Engine)", price: 79500 ,sdate:"11-12-98", edate:"12-12-98",hour:"6",status:"completed"
                ,task:"teaching",image:"./assets/nik/d3.jpg"},
        ],
        orders: []
    }
}
