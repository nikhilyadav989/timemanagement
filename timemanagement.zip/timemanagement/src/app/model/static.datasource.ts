import { Injectable } from "@angular/core";
import { Product } from "./product.model";
import { Observable, from } from "rxjs";
import { Order } from "./order.model";

@Injectable()
export class StaticDataSource {
    private products: Product[] = [
        new Product(1,1, "Product 1","", "sdate 1","edate 1",1,"status 1","Category 1", "Product 1 (Category 1)", 100),
        new Product(2,2, "Product 2","","sdate 2","edate 2", 2,"status 2","Category 1", "Product 2 (Category 1)", 100),
        new Product(3,3, "Product 3","","sdate 3","edate 3", 3,"status 3","Category 1", "Product 3 (Category 1)", 100),
        new Product(4,4, "Product 4","","sdate 4","edate 4", 4,"status 4","Category 1", "Product 4 (Category 1)", 100),
        new Product(5,5, "Product 5","","sdate 5","edate 5", 5,"status 5","Category 1", "Product 5 (Category 1)", 100),
        new Product(6,6, "Product 6","","sdate 6","edate 6", 6,"status 6","Category 2", "Product 6 (Category 2)", 100),
        new Product(7,7, "Product 7","","sdate 7","edate 7", 7,"status 7","Category 2", "Product 7 (Category 2)", 100),
        new Product(8,8, "Product 8","","sdate 8","edate 8", 8,"status 8","Category 2", "Product 8 (Category 2)", 100),
        new Product(9,9, "Product 9","","sdate 9","edate 9", 9,"status 9","Category 2", "Product 9 (Category 2)", 100),
        new Product(10,10, "Product 10","","sdate 10","edate 10",10,"status 10", "Category 2", "Product 10 (Category 2)", 100),
        new Product(11,11, "Product 11","","sdate 11","edate 11", 11,"status 11","Category 3", "Product 11 (Category 3)", 100),
        new Product(12,12, "Product 12","","sdate 12","edate 12", 12,"status 12","Category 3", "Product 12 (Category 3)", 100),
        new Product(13,13, "Product 13","","sdate 13","edate 13", 13,"status 13","Category 3", "Product 13 (Category 3)", 100),
        new Product(14,14, "Product 14","","sdate 14","edate 14", 14,"status 14","Category 3", "Product 14 (Category 3)", 100),
        new Product(15,15, "Product 15","","sdate 15","edate 15", 15,"status 15","Category 3", "Product 15 (Category 3)", 100),
    ];

    getProducts(): Observable<Product[]> {
        return from([this.products]);
    }

    saveOrder(order: Order): Observable<Order> {
        console.log(JSON.stringify(order));
        return from([order]);
    }
}
