export class Product {

    constructor(
        public id?: number,
        public tid?: number,
        public name?: string,
        public task?: string,
        public sdate?: string,
        public edate?: string,
        public hour?: number,
        public status?: string,
        public category?: string,
        public description?: string,
        public price?: number,
        public image?:string) { }
}
