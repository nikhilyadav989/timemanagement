import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { AppComponent } from "./app.component";
import { StoreModule } from "./home/home.module";
import { StoreComponent } from "./home/home.component";
import { CheckoutComponent } from "./home/checkout.component";
import { CartDetailComponent } from "./home/cartDetail.component";
import { RouterModule } from "@angular/router";
import { StoreFirstGuard } from "./storeFirst.guard";

@NgModule({
    imports: [BrowserModule, StoreModule,
        RouterModule.forRoot([
            {
                path: "home", component: StoreComponent,
                canActivate: [StoreFirstGuard]
            },
            {
                path: "cart", component: CartDetailComponent,
               
            },
            {
                path: "checkout", component: CheckoutComponent,
             
            },
            {
                path: "admin",
                loadChildren: "./admin/admin.module#AdminModule",
              
            },
            { path: "**", redirectTo: "/home" }
        ])],
    providers: [StoreFirstGuard],
    declarations: [AppComponent],
    bootstrap: [AppComponent]
})
export class AppModule { }
